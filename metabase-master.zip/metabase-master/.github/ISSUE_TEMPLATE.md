If this is a bug report, please fill in the blanks:

*  I am using the ___________ browser.
*  My computer's OS is ___________.
*  I'm running Metabase ___________ [locally from the JAR / locally with the Mac App / on AWS / on Herkou / etc.] and it is using the ___________ [Postgres / MySQL / H2 (default)] database.
*  My data is in a ___________ database. [Postgres / MySQL / Redshift / BigQuery / MongoDB / SQLite / SQL Server / etc.]
*  My Metabase version is ___________.
