//
//  LoadingView.h
//  Metabase
//
//  Created by Cam Saul on 10/14/15.
//  Copyright (c) 2015 Metabase. All rights reserved.
//

@import Cocoa;

@interface LoadingView : NSView

@property (nonatomic) BOOL animate;

@end
