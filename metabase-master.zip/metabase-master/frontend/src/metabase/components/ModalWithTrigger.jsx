import Triggerable from './Triggerable.jsx';
import Modal from './Modal.jsx';

export default Triggerable(Modal);
