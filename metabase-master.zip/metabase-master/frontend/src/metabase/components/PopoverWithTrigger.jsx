import Triggerable from './Triggerable.jsx';
import Popover from './Popover.jsx';

export default Triggerable(Popover);
