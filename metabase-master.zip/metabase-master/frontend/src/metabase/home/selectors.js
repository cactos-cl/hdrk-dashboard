export const getActivity 		= (state) => state.home && state.home.activity
export const getRecentViews 	= (state) => state.home && state.home.recentViews
export const getUser 			= (state) => state.currentUser
