/* @flow */

export type DatabaseId = number;
export type TableId = number;
